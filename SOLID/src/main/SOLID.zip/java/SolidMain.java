package main.java.SingleRespPrinciple;

public class SolidMain {
    public static void main(String[] args){

    }
}
