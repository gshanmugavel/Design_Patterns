package main.java.InterfaceSegOrLiskovSubsPrinciple.Solution;

public interface GenericPaymentType extends PaymentType {
}
