package main.java.DependencyInvPrinciple;

public class CardPayment {
    public boolean transactMoney(String from, String to, Long amount) {
        return true;
    }
}
