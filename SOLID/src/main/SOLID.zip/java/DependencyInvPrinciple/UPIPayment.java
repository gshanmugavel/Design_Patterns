package main.java.DependencyInvPrinciple;

public class UPIPayment {
    public boolean transactMoney(String from, String to, Long amount) {
        return true;
    }
}