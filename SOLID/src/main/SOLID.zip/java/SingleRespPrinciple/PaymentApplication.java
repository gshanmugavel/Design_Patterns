package main.java.SingleRespPrinciple;

public class PaymentApplication {
    public boolean sendMoney(){
        return true;
    }

    public boolean receiveMoney(){
        return true;
    }

    public boolean notifyUsers(){
        return true;
    }

    public boolean applyCoupon(){
        return true;
    }
}
