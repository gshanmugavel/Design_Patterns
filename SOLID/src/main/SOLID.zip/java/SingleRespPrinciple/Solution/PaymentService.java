package main.java.SingleRespPrinciple.Solution;

public class PaymentService {
    public boolean sendMoney(){
        return true;
    }
    public boolean receiveMoney(){
        return true;
    }
}
