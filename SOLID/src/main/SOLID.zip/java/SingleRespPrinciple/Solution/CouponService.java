package main.java.SingleRespPrinciple.Solution;

public class CouponService {
    public boolean applyCoupon(){
        return true;
    }
}
