package main.java.SingleRespPrinciple.Solution;

public class NotificationService {
    public boolean notifyUsers(){
        return true;
    }
}
